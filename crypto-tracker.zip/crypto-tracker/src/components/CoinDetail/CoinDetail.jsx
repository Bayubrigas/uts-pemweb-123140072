// components/CoinDetail/CoinDetail.jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './CoinDetail.css';

const CoinDetail = () => {
  const { id } = useParams();
  const [coin, setCoin] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCoinData = async () => {
      try {
        // 🔧 Perbaikan: Hapus spasi sebelum ${id}
        const response = await fetch(`https://api.coingecko.com/api/v3/coins/${id}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        setCoin(data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching coin data:", err);
        setError(err.message || "Gagal memuat data coin");
        setLoading(false);
      }
    };

    fetchCoinData();
  }, [id]);

  // Loading State
  if (loading) {
    return (
      <div className="coin-detail">
        <div className="loading">⏳ Memuat data coin...</div>
      </div>
    );
  }

  // Error State
  if (error) {
    return (
      <div className="coin-detail">
        <div className="error">
          ❌ {error}
          <br />
          <button onClick={() => window.location.reload()}>Coba Lagi</button>
        </div>
      </div>
    );
  }

  // Data Not Found
  if (!coin) {
    return (
      <div className="coin-detail">
        <div className="error">🚫 Coin tidak ditemukan.</div>
      </div>
    );
  }

  // Format number helper
  const formatNumber = (num) => {
    if (num === null || num === undefined) return "$0";
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };

  const formatPrice = (price) => {
    return price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Ambil data dengan safe access
  const {
    name = "Unknown",
    symbol = "N/A",
    market_cap_rank = "#?",
    image = { large: "https://via.placeholder.com/60" },
    current_price = 0,
    price_change_percentage_24h = 0,
    market_cap = { usd: 0 },
    total_volume = { usd: 0 },
    circulating_supply = 0,
    max_supply = null,
    links = { homepage: [], whitepaper: { link: "" } },
    community_score = 0,
    sentiment_votes_up_percentage = 82,
    sentiment_votes_down_percentage = 18,
    total_supply = 0
  } = coin;

  // 🔧 Handler untuk tombol
  const handleFollow = () => alert("Fitur Follow akan segera hadir!");
  const handleBuy = () => alert(`Membuka jendela pembelian untuk ${symbol.toUpperCase()}...`);
  const handleBoost = () => alert("Fitur Boost akan segera hadir!");
  const handleTabClick = (tabName) => alert(`Tab ${tabName} aktif!`);
  const handleSentimentClick = (type) => alert(`Anda memilih ${type} untuk coin ini.`);

  return (
    <div className="coin-detail">
      {/* Header Top */}
      <div className="header-top">
        <div className="coin-header-left">
          <img src={image.large || "https://via.placeholder.com/60"} alt={name} className="coin-logo" />
          <div>
            <h1>{name} <span className="symbol">{symbol.toUpperCase()}</span> <span className="rank">#{market_cap_rank}</span></h1>
            <div className="followers">3M Followers</div>
          </div>
        </div>

        <div className="header-actions">
          {/* 🔧 Fungsikan tombol */}
          <button className="btn-follow" onClick={handleFollow}>+ Follow</button>
          <button className="btn-buy" onClick={handleBuy}>Buy {symbol.toUpperCase()}</button>
        </div>
      </div>

      {/* Main Price */}
      <div className="main-price">
        <div className="price-large">${formatPrice(current_price)}</div>
        <div className={`change ${price_change_percentage_24h >= 0 ? 'positive' : 'negative'}`}>
          {price_change_percentage_24h >= 0 ? '+' : ''}{price_change_percentage_24h?.toFixed(2)}% (24h)
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="tabs">
        {/* 🔧 Fungsikan tombol tab */}
        <button className="tab active" onClick={() => handleTabClick('Chart')}>Chart</button>
        <button className="tab" onClick={() => handleTabClick('Markets')}>Markets</button>
        <button className="tab" onClick={() => handleTabClick('News')}>News</button>
        <button className="tab" onClick={() => handleTabClick('Yield')}>Yield</button>
        <button className="tab" onClick={() => handleTabClick('Market Cycles')}>Market Cycles</button>
        <button className="tab" onClick={() => handleTabClick('About')}>About</button>
      </div>

      {/* Main Content Grid */}
      <div className="content-grid">
        {/* Left Panel - Stats */}
        <div className="left-panel">
          <div className="stat-card">
            <div className="stat-label">Market cap</div>
            <div className="stat-value">{formatNumber(market_cap.usd)} <span className={`change ${price_change_percentage_24h >= 0 ? 'positive' : 'negative'}`}>{price_change_percentage_24h >= 0 ? '+' : ''}{price_change_percentage_24h?.toFixed(2)}%</span></div>
          </div>

          <div className="stats-row">
            <div className="stat-box">
              <div className="label">Volume (24h)</div>
              <div className="value">${formatNumber(total_volume.usd)} <span className="down">▼ 54.76%</span></div>
            </div>
            <div className="stat-box">
              <div className="label">FDV</div>
              <div className="value">{formatNumber(2.3e12)}</div>
            </div>
          </div>

          <div className="stats-row">
            <div className="stat-box">
              <div className="label">Vol/Mkt Cap (24h)</div>
              <div className="value">1.14%</div>
            </div>
            <div className="stat-box">
              <div className="label">Total supply</div>
              <div className="value">{total_supply?.toLocaleString()} {symbol.toUpperCase()}</div>
            </div>
          </div>

          <div className="stats-row">
            <div className="stat-box">
              <div className="label">Max. supply</div>
              <div className="value">{max_supply ? `${max_supply.toLocaleString()} ${symbol.toUpperCase()}` : 'Unlimited'}</div>
            </div>
            <div className="stat-box">
              <div className="label">Circulating supply</div>
              <div className="value">{circulating_supply?.toLocaleString()} {symbol.toUpperCase()} <span className="verified">✓</span></div>
            </div>
          </div>

          <div className="stat-card profile-score">
            <div className="label">Profile score</div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: '100%' }}></div>
              <span>100%</span>
            </div>
          </div>

          {/* 🔧 Fungsikan tombol Boost */}
          <div className="boost-button" onClick={handleBoost}>
            <span>🚀 Boost</span>
          </div>

          <div className="footer-links">
            {links.homepage?.[0] && (
              <a href={links.homepage[0]} target="_blank" rel="noopener noreferrer" className="link">Website</a>
            )}
            {links.whitepaper?.link && (
              <a href={links.whitepaper.link} target="_blank" rel="noopener noreferrer" className="link">Whitepaper</a>
            )}
          </div>
        </div>

        {/* Middle Panel - Chart */}
        <div className="middle-panel">
          <div className="chart-controls">
            <button className="chart-btn active">Price</button>
            <button className="chart-btn">Mkt Cap</button>
            <button className="chart-btn"><img src="https://cdn-icons-png.flaticon.com/512/1078/1078770.png" alt="Chart" width="16" /> TradingView</button>
            <div className="compare-dropdown">
              <button>Compare ▼</button>
            </div>
            <div className="timeframe">
              <button className="time active">24h</button>
              <button className="time">1M</button>
              <button className="time">All</button>
            </div>
          </div>

          <div className="chart-placeholder">
            <p>📊 Grafik harga real-time akan muncul di sini.</p>
            <p>(Integrasi TradingView atau Recharts diperlukan untuk grafik interaktif)</p>
          </div>

          <div className="chart-footer">
            <div className="timestamp">USD</div>
            <div className="volume-indicator">125</div>
          </div>
        </div>

        {/* Right Panel - Community & News */}
        <div className="right-panel">
          <div className="community-sentiment">
            <div className="sentiment-header">
              <h3>Community sentiment</h3>
              <span>5.2M votes</span>
              <div className="pagination">‹ 1/2 ›</div>
            </div>
            <div className="sentiment-bars">
              <div className="bullish-bar" style={{ width: `${sentiment_votes_up_percentage}%` }}>
                <span>{sentiment_votes_up_percentage}%</span>
              </div>
              <div className="bearish-bar" style={{ width: `${sentiment_votes_down_percentage}%` }}>
                <span>{sentiment_votes_down_percentage}%</span>
              </div>
            </div>
            <div className="sentiment-buttons">
              {/* 🔧 Fungsikan tombol sentiment */}
              <button className="btn-bullish" onClick={() => handleSentimentClick('Bullish')}>📈 Bullish</button>
              <button className="btn-bearish" onClick={() => handleSentimentClick('Bearish')}>📉 Bearish</button>
            </div>
          </div>

          <div className="news-section">
            <div className="news-tabs">
              <button className="news-tab active">Top</button>
              <button className="news-tab">Latest</button>
            </div>

            <div className="news-item">
              <div className="news-avatar">
                <img src="https://via.placeholder.com/30" alt="User" />
              </div>
              <div className="news-content">
                <div className="news-header">
                  <span>Crypto.Andy</span>
                  <span>• 17 hours</span>
                  {/* 🔧 Fungsikan tombol follow di news */}
                  <button className="follow-btn" onClick={handleFollow}>+ Follow</button>
                </div>
                <div className="news-text">
                  Yesterday, 💰 $BTC Turned 17 - and Faced Its First Red October in 7 Years
                </div>
              </div>
            </div>

            <div className="news-item">
              <div className="news-avatar">
                <img src="https://via.placeholder.com/30" alt="User" />
              </div>
              <div className="news-content">
                <div className="news-header">
                  <span>Satoshi Nakamoto</span>
                  <span>• 17 years ago</span>
                </div>
                <div className="news-text">
                  Seventeen years ago - on October 31, 2008 - Satoshi Nakamoto published the ...
                  <a href="#">Read all</a>
                </div>
                <div className="news-image">
                  <img src="https://via.placeholder.com/300x150?text=17+Years+Since+BTC+Revolution" alt="Bitcoin" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoinDetail;